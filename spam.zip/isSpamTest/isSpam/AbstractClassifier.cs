﻿using Microsoft.ML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace isSpam
{
    internal abstract class AbstractClassifier
    {
        public abstract bool PredictSpam(string userInput);
    }    
}
